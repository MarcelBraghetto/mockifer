Do not delete this folder.

The mock responses in this folder should map 1:1 with a route id.

Using the Mockifer editor will automatically create/update/delete these files.